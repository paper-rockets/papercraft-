Paper 3D blocks test (3 Oct 2026).
Unzip, then serve this folder with any web server, for example:
  python -m http.server 8000
Open http://localhost:8000/blocks3d-three.html (new, three.js) or /blocks3d-test.html (old).
Double-clicking the html file will not work (the browser blocks the module files).
